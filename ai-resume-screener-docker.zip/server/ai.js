import OpenAI from "openai";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function scoreResumes(resumes, criteria) {
  const prompt = `You are an HR assistant. Rank the following resumes based on these weights:
  Experience: ${criteria.experience}, Skills: ${criteria.skills}, Education: ${criteria.education}.
  Return JSON array like [{\"name\":\"Candidate 1\",\"score\":85}].

Resumes:
${resumes.map((r, i) => `Candidate ${i + 1}:\n${r}`).join("\n\n")}`;

  const response = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [{ role: "user", content: prompt }]
  });

  const content = response.choices[0].message.content;
  try {
    return JSON.parse(content);
  } catch {
    return resumes.map((_, i) => ({ name: `Candidate ${i + 1}`, score: 0 }));
  }
}
