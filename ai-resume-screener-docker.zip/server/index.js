import express from "express";
import formidable from "formidable";
import fs from "fs";
import dotenv from "dotenv";
import { scoreResumes } from "./ai.js";

dotenv.config();
const app = express();

app.post("/api/score", (req, res) => {
  const form = formidable({ multiples: true });
  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(400).json({ error: "Upload failed" });

    const criteria = JSON.parse(fields.criteria);
    const resumes = Array.isArray(files.resumes) ? files.resumes : [files.resumes];

    const texts = await Promise.all(resumes.map(async (file) => {
      const buffer = fs.readFileSync(file.filepath);
      const ext = file.originalFilename.split(".").pop();
      if (ext === "pdf") {
        const pdf = await import("pdf-parse");
        const data = await pdf.default(buffer);
        return data.text;
      } else if (["docx", "doc"].includes(ext)) {
        const mammoth = await import("mammoth");
        const { value } = await mammoth.extractRawText({ buffer });
        return value;
      } else {
        return buffer.toString();
      }
    }));

    const rankings = await scoreResumes(texts, criteria);
    res.json({ rankings });
  });
});

app.listen(process.env.PORT || 5000, () => {
  console.log("Server running on port", process.env.PORT || 5000);
});
