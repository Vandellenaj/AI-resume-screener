# AI HR Resume Screener
Ready-to-deploy website with React (Vite) frontend and Node.js (Express) backend.
See README inside for setup and deployment instructions.
