import React, { useState } from "react";

function App() {
  const [resumes, setResumes] = useState([]);
  const [criteria, setCriteria] = useState({ experience: 1, skills: 1, education: 1 });
  const [results, setResults] = useState([]);

  const handleUpload = (e) => {
    setResumes(Array.from(e.target.files));
  };

  const handleScore = async () => {
    const formData = new FormData();
    resumes.forEach((file) => formData.append("resumes", file));
    formData.append("criteria", JSON.stringify(criteria));

    const res = await fetch("http://localhost:5000/api/score", { method: "POST", body: formData });
    const data = await res.json();
    setResults(data.rankings);
  };

  return (
    <div className="p-6">
      <h1>AI Resume Screener</h1>
      <input type="file" multiple onChange={handleUpload} />
      <div>
        {Object.keys(criteria).map((key) => (
          <div key={key}>
            <label>{key}: </label>
            <input
              type="number"
              value={criteria[key]}
              onChange={(e) => setCriteria({ ...criteria, [key]: parseFloat(e.target.value) })}
            />
          </div>
        ))}
      </div>
      <button onClick={handleScore}>Rank Resumes</button>
      <ul>
        {results.map((r, i) => (
          <li key={i}>{r.name} - Score: {r.score}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
